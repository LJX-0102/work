# Frame 单 Job / PHYS+AUX 双层时间自适应算例包 — FIX15

FIX15 以 FIX14 已跑通的 single Job、22 个外层轨迹段以及每段固定 `PHYS + 0.01 s AUX` 架构为基础，仅修正净热流 accepted-end 记录与后处理数据源，不改变时间自适应控制律。

## 核心原则

- 外层：仍由全轨迹感知预先确定 5–100 s 自适应耦合区间。
- 每个外层区间：严格为 `PHYS=(dt_c-0.01 s) + AUX=0.01 s`；AUX 仅用于 UMESHMOTION 退缩/几何状态同步。
- 内层 PHYS：全过程允许 `1–100 s`，跨 AUX/轨迹段连续继承上一 accepted increment，不因外层边界重置。
- 下一内层增量仍只由三项共同决定：前一 accepted PHYS increment、accepted-end 表面最高温度变化速率 `|dT/dt|`、当前轨迹段已知的外部气动热载变化率（`q_cw` 与 `Haw` 端点场）。
- `q_net` 不参与时间步控制；`DELTMX=500 K` 仅为数值安全上限。

## FIX15 唯一核心修改：统一 PHYS/AUX 净热流记录

FIX14 的物理热边界本身连续，但上一轮绘图把 PHYS 的 `qnet_end_mW_mm2` 与 AUX-end ODB `SDV14` 混在同一条曲线上。由于 `SDV14` 是经 `DFLUX -> COMMON -> UMAT -> STATEV` 转存的诊断量，AUX ODB 中可能存在迭代滞后，因此外层实心点会系统性偏低并形成假锯齿。

FIX15 不再用 ODB `SDV14` 作为净热流曲线数据源。DFLUX 对 PHYS 和 AUX 都写入同一套 accepted-end 诊断数组，并在每个 accepted increment 结束时输出：

`jobs/qnet_accepted_history.dat`

字段为：

`time_s accepted_dt_s kstep kinc phase_code qnet_end_mW_mm2 TendMax_K`

其中：

- `phase_code=1`：PHYS accepted increment，后处理画为空心点；
- `phase_code=2`：0.01 s AUX accepted increment，对应外层轨迹/耦合边界，后处理画为实心点。

因此净热流曲线的空心点和实心点完全来自同一个 DFLUX accepted-end 数据链，不再混用 ODB `SDV14`。

## 运行

双击 `RUN_ADAPT_CASE.bat`。Abaqus 路径：`C:\SIMULIA\Commands\abaqus.bat`。

运行完成后，净热流曲线优先使用 `qnet_accepted_history.dat`；`inner_increment_control_history.dat` 继续用于内层时间步、温度变化率和外载上限诊断。
